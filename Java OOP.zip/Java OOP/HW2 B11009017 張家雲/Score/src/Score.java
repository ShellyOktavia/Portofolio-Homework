import java.util.Scanner;

public class Score {
    public static void main(String[] args) {
        int i;
        int n;
        float [] score = new float[11];
        Scanner scanner = new Scanner (System.in);
        for (i =1; i<score.length;i++) {
            System.out.printf("%s %d %s", "第 ", i ,"位: " );
            score[i] = scanner.nextFloat();
        }
        System.out.println("=========================");
        for (n = 1; n < score.length; n++) {
            System.out.println("第 " + n  + " 位: " + score[n]);
        }
        float sum = 0;
        for (int a = 1; a < score.length; a++){
            sum += score[a];
        }
        float average = sum/(score.length-1);
        System.out.println(" ");
        System.out.println("平均: "+ average + "分" );
        System.out.println("變異數: " + sum + "分");
        float maximum = 0;
        for (int b = 1; b < score.length; b++){
            if (score[b]> maximum){
                maximum = score[b];
            }
        }
        float minimum = score[1];
        for (int c = 1; c < score.length; c++){
            if (score[c]< minimum){
                minimum = score[c];
            }
        }
        System.out.println("最高分: " + maximum + "分");
        System.out.println("最低分: " + minimum + "分");

        int[] count = new int [5];
        for (int d =1; d < score.length; d++){
            if (score[d]>=90 && score [d]<=100){
                count[0]++;
            }else if (score[d]>=80 && score[d]<=89){
                count[1]++;
            }else if (score[d]>=70 && score[d]<=79){
                count[2]++;
            }else if (score[d]>=60 && score[d]<=69){
                count[3]++;
            }else {
                count[4]++;
            }
        }
        System.out.println("分數介於90-100人數：" + count[0] + "人");
        System.out.println("分數介於80-89人數：" + count[1] + "人");
        System.out.println("分數介於70-79人數：" + count[2] + "人");
        System.out.println("分數介於60-69人數：" + count[3] + "人");
        System.out.println("分數介於0-59人數：" + count[4] + "人");
    }
}
