import java.io.*;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.Comparator;

public class List {
    public static void main(String[] args) throws Exception {
        List<UsageInfo> usageInfo = new ArrayList<>();

        try {
            BufferedReader input = new BufferedReader((new InputStreamReader(new FileInputStream("cell.csv")))) {
                while(true)

                {
                    String line = input.readLine();
                    if (line == null) {
                        break;
                    }
                    int userCount = Integer.parseInt(line[0]);
                    YearMonth yearMonth = YearMonth.parse(line[1]);

                    usageInfo.add(new UsageInfo(userCount, yearMonth));
                }
            }
        }
    }
}