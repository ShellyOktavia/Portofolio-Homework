import java.time.YearMonth;
import java.util.ArrayList;

public class UsageInfo {
    String company;
    YearMonth yearMonth;
    int minutecalls;
    int userCount;

   public UsageInfo(String company, int userCount,YearMonth yearMonth, int minutecalls) {
       this.company = company;
       this.userCount = userCount;
       this.yearMonth = yearMonth;
       this.minutecalls = minutecalls;
   }
   public String getCompany(){
       return this.company;
   }
   public int getUserCount(){
       return this.userCount;
    }
    public YearMonth getYearMonth() {
        return this.yearMonth;
    }

    public int getMinutecalls(){
       return this.minutecalls;
    }
}