public class ParseUrl{
    String urlString;
    String protocol;
    String host;
    String path;
    String filename;
    String query;

    public void parse (String urlString){
        this.urlString = urlString;
        System.out.println("Input: "+urlString);

        int index1 = urlString.indexOf(":");
        protocol = urlString.substring(0, index1);

        urlString = urlString.substring(index1 + 3, urlString.length());
        int index2 = urlString.indexOf("/");
        host = urlString.substring(0, index2);

        urlString = urlString.substring(index2, urlString.length());
        int index3 = urlString.lastIndexOf("/")+1;
        path = urlString.substring(0, index3);

        urlString = urlString.substring(index3, urlString.length());
        int index4 = urlString.indexOf("?");
        filename = urlString.substring(0, index4);

        urlString = urlString.substring(index4 + 1, urlString.length());
        query = urlString;
    }

    public String toString(){
        return "protocol: "+ protocol +"\nhost: "+ host +"\npath: "+ path + "\nfilename: "+ filename + "\nquery: "+ query;
    }
}
