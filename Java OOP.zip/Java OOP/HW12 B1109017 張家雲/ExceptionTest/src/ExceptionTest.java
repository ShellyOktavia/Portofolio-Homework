import java.util.Scanner;

public class ExceptionTest {
    public static void main(String[] args) throws Exception {
        try{
            checkNum();
        } catch (NumberFormatException e){
            System.out.println("The age you enter was too BIG");
        } finally {
            System.out.println("Exit Program");
        }
    }

  public static void checkNum(){
        Scanner input = new Scanner(System.in);
        System.out.println("Please Input a Age : ");
        int num = input.nextInt();
      try {
          if (20<=num && num<=50) {
              System.out.println("The age you enter = "+num);
          } else if (num < 20) {
              throw new ArithmeticException();
          } else {
              throw new NumberFormatException();
          }
      }catch (ArithmeticException e) {
          System.out.println("The age you enter was too SMALL");
      }
  }
}