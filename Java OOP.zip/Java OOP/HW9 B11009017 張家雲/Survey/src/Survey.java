import java.io.IOException;
import java.nio.file.Paths;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class Survey {
    private static Scanner input;
    private static int surveyresult[][];

    private static double TotaleachPerson;
    private static double AverageeachPerson;

    private static int highest;
    private static int lowest;

    private static double sumQuestion;
    private static double averageQuestion;

    public static void main(String[] args) {
        openfile();
        surveyresult = readFile();
        display(surveyresult);
        AverageeachRespondent(surveyresult);
        HighesteachQuestion(surveyresult);
        lowesteachQuestion(surveyresult);
        AverageeachQuestion(surveyresult);
    }
    public static void openfile() {
        try {
            input = new Scanner (Paths.get("C:\\Users\\Shelly Chang\\IdeaProjects\\Survey\\log.txt"));
        }
        catch (IOException IOException) {
            System.err.println("Error Opening File.");
        }
    }

    public static int[][] readFile() {
        int survey[][] = new int[10][6];
        try {
            for (int Person = 0; Person < survey.length; Person++) {
                if (input.hasNext()) {
                    String currentLine = input.next();
                    String tokens[] = currentLine.split(",");
                    for (int Question = 0; Question < survey[Person].length; Question++) {
                        survey[Person][Question] = Integer.parseInt(tokens[Question]);
                    }
                }
            }

        } catch (NoSuchElementException elementexception) {
            System.err.println("File Improperly Formed");
        }
        return survey;
    }

    public static void display(int surveyresult[][]) {
        for (int Person = 0; Person < surveyresult.length; Person++) {
            System.out.println("Person " + (Person + 1) + "Survey Result :");
            for (int Question = 0; Question < surveyresult[Person].length; Question++) {
                System.out.println(surveyresult[Person][Question] + "\t");
            }
            System.out.println();
        }
        System.out.println();
    }

    public static void AverageeachRespondent(int[][] surveyresult) {
        for (int Person = 0; Person < surveyresult.length; Person++) {
            TotaleachPerson = 0;
            AverageeachPerson = 0;
            for (int Question = 0; Question < surveyresult[Person].length; Question++) {
                TotaleachPerson += surveyresult[Person][Question];
            }
            AverageeachPerson = TotaleachPerson / (surveyresult[Person].length);
            System.out.println("Person " + (Person + 1) + "Average : ");
            System.out.printf("%.2f", AverageeachPerson);
            System.out.println();
        }
        System.out.println();
    }

    public static void HighesteachQuestion(int[][] surveyresult) {
        for (int Question = 0; Question < surveyresult[Question].length; Question++) {
            highest = 0;
            for (int Person = 0; Person < surveyresult.length; Person++) {
                if (highest < surveyresult[Person][Question]) {
                    highest = surveyresult[Person][Question];
                }
            }
            System.out.println("Question " + (Question + 1) + "Highest : " + highest);
        }
        System.out.println();
    }

    public static void lowesteachQuestion(int surveyresult[][]) {
        for (int Question = 0; Question < surveyresult[Question].length; Question++) {
            lowest = 10;
            for (int Person = 0; Person < surveyresult.length; Person++) {
                if (lowest > surveyresult[Person][Question]) {
                    lowest = surveyresult[Person][Question];
                }
            }
            System.out.println("Question " + (Question + 1) + " lowest: " + lowest);
        }
        System.out.println();
    }

    public static void AverageeachQuestion(int surveyresult[][]) {
        for (int Question = 0; Question < surveyresult[Question].length; Question++) {
            sumQuestion = 0;
            averageQuestion = 0;
            for (int Person = 0; Person < surveyresult.length; Person++) {
                sumQuestion += surveyresult[Person][Question];
            }
            averageQuestion = sumQuestion / surveyresult.length;
            System.out.println("Question " + (Question + 1) + " average: " + averageQuestion);
        }
        System.out.println();
    }
}