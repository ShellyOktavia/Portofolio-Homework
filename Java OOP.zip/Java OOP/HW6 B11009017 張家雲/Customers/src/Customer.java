import java.io.Serializable;

enum Sex{
    MALE, FEMALE
}
public class Customer implements Serializable {
    String name;
    Sex sex;
    Date birthday;
    String phoneString;

    public Customer(String n, Sex s, Date d, String p){
        name = n;
        sex = s;
        birthday = d;
        phoneString = p;
    }
    public String toString(){
        return name + ", "+sex + "," + birthday+ "," + phoneString;

    }

}
