import java.io.*;

public class CustomerTest {
    public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException {
        try {
            BufferedReader input = new BufferedReader(new InputStreamReader(new FileInputStream("customers.txt"), "big5"));
            Customer customers[] = new Customer[5];
            int index = 0;

            while (true) {
                String line = input.readLine();
                if (line == null) {
                    break;
                }
                String tokens[] = line.split(",");
                if (tokens.length == 0) {
                    break;
                }
                String name = tokens[0], sex = tokens[1], birthday = tokens[2], phoneString = tokens[3];
                Sex sex1 = Sex.valueOf(sex);
                String births[] = birthday.split("/");
                int yy = Integer.parseInt(births[0]), mm = Integer.parseInt(births[1]), dd = Integer.parseInt(births[2]);
                customers[index] = new Customer(name, sex1, new Date(yy, mm, dd), phoneString);
                index++;
            }
            FileOutputStream fos = new FileOutputStream("customers.dat");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(customers);
            oos.close();

            ObjectInputStream ois = new ObjectInputStream(new FileInputStream("customers.dat"));
            Object object = null;
            object = ois.readObject();
            Customer[] customer = (Customer[]) object;
            for (int i = 0; i < 5; i++) {
                System.out.println(customer[i]);
            }
        }
        catch (FileNotFoundException e) {
            System.out.println("File Not Found");
        }
        catch (IOException e){
            System.out.println("File Not Found");
            }
    }
}