import java.io.Serializable;

public class Date implements Serializable {
    int year, month, day;
    public Date (int yy, int mm, int dd){
        year = yy;
        month = mm;
        day = dd;
    }
    public String toString(){
        return String.format ("%04d/%02d/%02d", year, month, day);
    }

}
