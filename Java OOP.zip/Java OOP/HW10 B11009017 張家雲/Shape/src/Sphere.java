public class Sphere extends ThreeDimensionalShape {
    double radius;
    public Sphere(double r){
        setRadius(r);
    }
    public double getRadius(){
        return radius;
    }
    public void setRadius(double r){
        if(r >= 0)radius = r;
    }
    public double getSurfaceArea(){
        return 4 * Math.PI * radius * radius;
    }
    public double getVolume(){
        return 4/3 * Math.PI * radius * radius * radius;
    }
    public String toString() {
        return String.format("radius: %.2f\n"+"surface area: %.2f\n"+"volume: %.2f",radius,getSurfaceArea(),getVolume());
    }
}