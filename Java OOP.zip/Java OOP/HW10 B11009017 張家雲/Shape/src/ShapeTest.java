public class ShapeTest {
    public static void main(String[] args) {
        Sphere sphere = new Sphere(7);
        Cube cube = new Cube(8);
        System.out.println("The Sphere is : \n" + sphere);
        System.out.println("The Cube is :\n + Cube");
    }
}