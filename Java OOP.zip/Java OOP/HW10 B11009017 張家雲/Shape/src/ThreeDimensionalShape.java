public abstract class ThreeDimensionalShape {
    public abstract double getSurfaceArea();
    public abstract double getVolume();
}
