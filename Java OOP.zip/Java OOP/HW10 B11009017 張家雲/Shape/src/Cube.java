public class Cube extends ThreeDimensionalShape {
    double Side;
    public Cube(double S){
        Side = S;
    }
    public double getSurfaceArea(){
        return 6 * Side * Side;
    }
    public double getVolume() {
        return Side * Side * Side;
    }

    public String toString() {
        return String.format("side: %s\n"+"Surface Area: %.2f\n"+"Volume: %.2f\n",Side, getSurfaceArea(),getVolume());
    }
}