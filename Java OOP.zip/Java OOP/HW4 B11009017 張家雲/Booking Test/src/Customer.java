public class Customer {
    String surname;
    Title title;
    String phone;
    public Customer(String s, Title t, String p){
        surname = s;
        title = t;
        phone = p;
    }
    public void setPhone(String p){
    }
    public String toString(){
        return title + " " + surname + " " + phone;
    }
}
