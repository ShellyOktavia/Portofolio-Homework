import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class Booking {
    Customer customer;
    int numAdults, numKids;
    LocalDateTime bookingTime;

    public Booking(int A, int K, LocalDateTime T) {
        numAdults = A;
        numKids = K;
        bookingTime = T;
    }

    public LocalDateTime getBookingTime() {
        return bookingTime;
    }

    public void setBookingTime(LocalDateTime T) {
        bookingTime = T;
    }

    public String toString() {
        DateTimeFormatter myFormat = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
        String formattedDate = bookingTime.format(myFormat);
        return "Adults: " + numAdults + " Kids: " + numKids + " Booking Time: " + formattedDate;
    }
}
