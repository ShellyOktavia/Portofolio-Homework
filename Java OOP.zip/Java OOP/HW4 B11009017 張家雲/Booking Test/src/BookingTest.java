import java.time.LocalDateTime;
import java.util.Date;

public class BookingTest {
    public static void main(String[] args) {
        LocalDateTime d = LocalDateTime.now();
        Customer c1 = new Customer("Zhang", Title.MS, "0912345678");
        Booking b1 = new Booking(2, 2, d);
        System.out.println("Customer data : " + c1);
        System.out.println("booking data : " + b1);
    }
}