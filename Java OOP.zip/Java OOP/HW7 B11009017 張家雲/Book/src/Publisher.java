public class Publisher {
    String corp;
    String address;
    public Publisher(String c, String ad){
        corp = c;
        address = ad;
    }
    public String toString(){
        return String.format ("\ncorp: %S \naddress: %s", corp, address);
    }
}
