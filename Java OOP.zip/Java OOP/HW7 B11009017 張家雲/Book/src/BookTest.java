public class BookTest {
    public static void main (String args[]){
        Author author1[] = {new Author("Willy", "Zhang"), new Author("Ferly", "Kennedy")};
        Author author2[] = {new Author("Lovelyn", "Loewe"), new Author("Winna", "Halim"), new Author("Winny", "Halim")};
        Publisher publisher1 = new Publisher("MrGram","2468 5th Aw. Brock, LN. American. 0000 Brockly. Columbus, AL. American");
        Date date1 = new Date(2020, 05, 15);
        Date date2 = new Date (2022, 02, 12);
        Book book1 = new Book ("Programming For Beginners", "1234", author1, publisher1, date1);
        Book book2 = new Book ("What is Information Managment System ?", "4567", author2, publisher1, date2);
        System.out.println(book1);
        System.out.println("----------------------------------------");
        System.out.println(book2);
    }
}

