public class Author {
    String firstname;
    String lastname;
    public Author (String f, String l){
        firstname = f;
        lastname = l;
    }
    public String toString(){
        return String.format ("%s,%s", firstname, lastname);
    }
}
