public class Book {
    String bookName;
    String isbn;
    Author authors[];
    Publisher publisher;
    Date date;

    public Book(String n, String i, Author a[], Publisher p, Date d) {
        bookName = n;
        isbn = i;
        authors = a;
        publisher = p;
        date = d;
    }
    public String toString() {
        StringBuilder string = new StringBuilder();
        for(int i =0;i<authors.length;i++) {
            if (i >0) {
                string.append("; ");
            }
            string.append(authors[i]);
        }
        return "bookName: "+bookName+ "\nisbn: "+ isbn + "\nauthor: "+ string + "\npublisher: "+publisher + "\npublishingDate: "+ date;
    }
}

