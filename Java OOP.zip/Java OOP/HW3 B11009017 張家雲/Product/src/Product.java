import java.util.Scanner;

public class Product {
    public static void main(String[] args) {
        int n;
        Scanner scanner = new Scanner(System.in);
        System.out.println("dimension = ");
        n = scanner.nextInt();
        double x [] = new double [n];
        System.out.println("x = ");
        for (int i = 0; i < n; i++){
            x[i] = scanner.nextDouble();
        }
        double y [] = new double [n];
        System.out.println("y = ");
        for(int i = 0; i < n; i++){
            y[i] = scanner.nextDouble();
        }
        System.out.println("(x,y) = " + innerProduct(x,y));
        System.out.println("|x| = " + norm2(x));
        System.out.println("Cos A = "+ cosine(x,y));
        System.out.println("A = " + Math.toDegrees(Math.acos(cosine(x,y))));
    }
    static double innerProduct(double x[], double y[]){
        double multiple = 0;
        for(int i = 0; i < x.length; i++){
            multiple += x[i]*y[i];
        }
        return multiple;
    }
    static double norm2(double x[]){
        double total = 0;
        double normal;
        for(int i = 0; i < x.length; i++){
            total += x[i]*x[i];
        }
        normal = Math.sqrt(total);
        return normal;
    }
    static double cosine(double x[], double y[]){
        double cosine = 0;
        cosine = innerProduct(x,y)/(norm2(x)*norm2(y));
        return cosine;
    }
}