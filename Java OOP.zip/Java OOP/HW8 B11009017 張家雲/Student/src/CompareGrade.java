import java.util.Comparator;

public class CompareGrade implements Comparator<Student> {
    public int compare (Student x, Student y){
        int StringValueDifference = x.name.compareTo(y.name);
        return StringValueDifference;
    }
}
