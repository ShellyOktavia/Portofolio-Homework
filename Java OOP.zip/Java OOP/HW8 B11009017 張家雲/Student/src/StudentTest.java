import java.util.Arrays;

public class StudentTest {
    public static void main(String[] args) {
        sortStudentArray();
    }

    private static void sortStudentArray() {
        Student[] students = {new Student("Caleb", 104992, 99), new Student("Derek", 102113, 88), new Student("Dylan", 101111, 12), new Student("Anthony", 109123, 13), new Student("Bruce", 102334, 12), new Student("Spike", 110222, 1)};
        System.out.println("---------Before Sorting---------");
        for (int i = 0; i < students.length; i++) {
            System.out.println(students[i]);
        }

        sortbynames(students);
    }
    private static void sortbynames(Student students[]) {
        CompareName namecomparator = new CompareName();
        Arrays.sort(students, namecomparator);
        System.out.println("-----after sorting by names------");
        for (int i = 0; i < students.length; i++) {
            System.out.println(students[i]);
        }
        sortbyID(students);
    }
    private static void sortbyID(Student students[]){
        CompareID idcomparator = new CompareID();
        Arrays.sort(students, idcomparator);
        System.out.println("-----after sorting by ID------");
        for(int i = 0; i < students.length; i++){
            System.out.println(students[i]);
        }
        sortbyGrade(students);
    }
    private static void sortbyGrade(Student students[]){
        CompareGrade gradecomparator = new CompareGrade();
        Arrays.sort(students, gradecomparator);
        System.out.println("-----after sorting by grade------");
        for(int i = 0; i < students.length; i++){
            System.out.println(students[i]);
        }

    }
}
