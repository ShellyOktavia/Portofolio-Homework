import java.util.Comparator;

public class CompareID implements Comparator<Student> {
    public int compare(Student x, Student y){
        return x.id - y.id;
    }

}
