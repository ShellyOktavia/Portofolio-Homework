import java.util.Comparator;

public class CompareName implements Comparator <Student> {
    public int compare(Student x, Student y){
        int StringValueDifference = x.name.compareTo(y.name);
        return StringValueDifference;
    }
}
