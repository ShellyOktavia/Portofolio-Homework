public class Student {
    String name;
    int id;
    int grade;
    public Student (String n, int i, int g){
        name = n;
        id = i;
        grade = g;
    }
    public String toString(){
        return String.format("%s" + "%d" + "%d", name, id, grade);
    }
}