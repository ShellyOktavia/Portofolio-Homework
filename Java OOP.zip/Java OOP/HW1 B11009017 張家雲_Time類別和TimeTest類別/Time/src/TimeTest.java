public class TimeTest {
    public static void main(String[] args) {
        Time T1 = new Time(10);
        System.out.println("The time is " + T1);
        System.out.println("IS T1 morning ?" + T1.isMorning());

        T1.setHour(3);
        System.out.println("The time is "+T1);
        System.out.println("Is T1 noon?"+T1.isNoon());

        Time T2 = new Time(15,30);
        System.out.println("The time is "+T2);
        System.out.println("Is T2 afternoon?"+T2.isAfternoon());

        Time T3 = new Time (15, 30, 59);
        System.out.println("The time is "+T3);
        System.out.println("Is T3 evening?"+T3.isEvening());
    }
}