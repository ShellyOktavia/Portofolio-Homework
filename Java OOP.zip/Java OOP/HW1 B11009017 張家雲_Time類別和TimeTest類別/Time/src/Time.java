public class Time {
    private int hour;
    private int minute;
    private int second;

    public Time(int hh){
        if(hh < 00 || hh > 24) hour = 00;
        else hour = hh;
    }
    public int getHour(){
        return hour;
    }
    public void setHour(int hh){
        if(hh >= 00  && hh <= 24 ) hour = hh;
    }

    public Time(int hh, int mm){
        if(hh < 00 || hh > 24) hour = 00;
        else hour = hh;
        if(mm < 00 || mm > 60) minute = 00;
        else minute = mm;
    }
    public int getMinute(){
        return minute;
    }
    public void setMinute(int mm) {
        if(mm >= 00  && mm <= 60) minute = mm;
    }
    public Time(int hh, int mm, int ss) {
        if (hh < 00 || hh > 24) hour = 00;
        else hour = hh;
        if (mm < 00 || mm > 60) minute = 00;
        else minute = mm;
        if (ss < 00 || ss > 60) second = 00;
        else second = ss;
    }
    public int getSecond() {
        return second;
    }
    public void setSecond(int ss) {
       if(ss >= 00 && ss <= 60) second = ss;
    }
    public boolean isMorning() {
        if(hour >= 00 && hour < 12) return true;
        else return false;
    }
    public boolean isNoon(){
        if(hour >= 12 && hour < 13) return true;
        else return false;
    }
    public boolean isAfternoon(){
        if(hour >= 13 && hour < 18) return  true;
        else return false;
    }
    public boolean isEvening(){
        if(hour >= 18 && hour < 24) return true;
        else return false;
    }
    public String toString (){
        return String.format("%02d:%02d:%02d", hour, minute, second);
    }
}
